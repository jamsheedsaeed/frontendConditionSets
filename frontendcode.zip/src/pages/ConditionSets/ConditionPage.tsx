import React from 'react';
import ConditionSets from './ConditionSets';

const ConditionPage: React.FC = () => {
  return (
      <div >
        <ConditionSets />
      </div>
  );
};

export default ConditionPage;
