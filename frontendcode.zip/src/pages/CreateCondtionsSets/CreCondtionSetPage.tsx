import React from 'react';
import CreateConditionSets from './CreateConditionSets';

const CreCondtionSetPage: React.FC = () => {
  return (
      <div >
        <CreateConditionSets />
      </div>
  );
};

export default CreCondtionSetPage;
